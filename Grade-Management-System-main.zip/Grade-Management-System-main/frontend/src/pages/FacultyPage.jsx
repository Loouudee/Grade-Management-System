import React from 'react';

const FacultyPage = () => {
  return (
    <div>
      <h1>Welcome, Faculty Member!</h1>
      <p>This page is only accessible by faculty members.</p>
    </div>
  );
};

export default FacultyPage;
