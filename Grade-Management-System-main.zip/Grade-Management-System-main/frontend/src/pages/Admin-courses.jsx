import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const AdminCourses = () => {
  const [courses, setCourses] = useState([
    {
      id: 1,
      title: "How To Create Mobile Apps Using Ionic",
      category: "Mobile Application",
      price: "$99.00",
      image: "/assets/images/course_1.jpg",
    },
    {
      id: 2,
      title: "Learn React from Scratch",
      category: "Web Development",
      price: "$120.00",
      image: "/assets/images/course_2.jpg",
    },
  ]);

  const [newCourse, setNewCourse] = useState({
    title: "",
    category: "",
    price: "",
    image: "",
  });

  const [editCourseId, setEditCourseId] = useState(null);
  const [editedCourse, setEditedCourse] = useState({});
  const [newImageName, setNewImageName] = useState('');
  const [editedImageNames, setEditedImageNames] = useState({});

  const handleAddCourse = () => {
    if (!newCourse.title || !newCourse.image) return;

    setCourses([...courses, { ...newCourse, id: Date.now() }]);
    setNewCourse({ title: "", category: "", price: "", image: "" });
    setNewImageName('');
  };

  const handleDeleteCourse = (id) => {
    setCourses(courses.filter((course) => course.id !== id));
  };

  const handleEditCourse = (course) => {
    setEditCourseId(course.id);
    setEditedCourse({ ...course });
  };

  const handleSaveCourse = () => {
    setCourses(
      courses.map((course) => (course.id === editCourseId ? editedCourse : course))
    );
    setEditCourseId(null);
    setEditedCourse({});
  };

  const handleCancelEdit = () => {
    setEditCourseId(null);
    setEditedCourse({});
  };

  return (
    <>
        {/* Top Bar */}
              <div className="py-2 bg-light">
                <div className="container">
                  <div className="row align-items-center">
                    <div className="col-lg-9 d-none d-lg-block">
                      <Link to="#" className="small mr-3">
                        <span className="icon-question-circle-o mr-2" /> Have a question?
                      </Link>
                      <Link to="#" className="small mr-3">
                        <span className="icon-phone2 mr-2" /> 10 20 123 456
                      </Link>
                      <Link to="#" className="small mr-3">
                        <span className="icon-envelope-o mr-2" /> info@mydomain.com
                      </Link>
                    </div>
                    <div className="col-lg-3 text-right">
                      <Link to="/login" className="small mr-3">
                        <span className="icon-unlock-alt" /> Log In
                      </Link>
                      <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                        <span className="icon-users" /> Register
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
                {/* Header / Navbar */}
            <header className="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
                <div className="container">
                    <div className="d-flex align-items-center">
                    <div className="site-logo">
                        <Link to="/" className="d-block">
                        <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
                        </Link>
                    </div>
                    <div className="mr-auto">
                        <nav className="site-navigation position-relative text-right" role="navigation">
                        <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                            <li>
                            <Link to="/" className="nav-link text-left">Home</Link>
                            </li>
                            
                            <li className="active">
                            <Link to="/admissions" className="nav-link text-left">Admissions</Link>
                            </li>
                            <li>
                            <Link to="/courses" className="nav-link text-left">Courses</Link>
                            </li>
                            <li>
                            <Link to="/contact" className="nav-link text-left">Contact</Link>
                            </li>
                        </ul>
                        </nav>
                    </div>
                    <div className="ml-auto">
                        <div className="social-wrap">
                        <Link to="#"><span className="icon-facebook"></span></Link>
                        <Link to="#"><span className="icon-twitter"></span></Link>
                        <Link to="#"><span className="icon-linkedin"></span></Link>
                        <Link to="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
                            <span className="icon-menu h3" />
                        </Link>
                        </div>
                    </div>
                    </div>
                </div>
            </header>
      {/* Add Course Form */}
      <div className="container my-5">
        <h3>Add New Course</h3>
        <div className="row mb-4">
          <div className="col-md-3">
            <input
              type="text"
              className="form-control"
              placeholder="Title"
              value={newCourse.title}
              onChange={(e) =>
                setNewCourse({ ...newCourse, title: e.target.value })
              }
            />
          </div>

          <div className="col-md-2">
            <input
              type="text"
              className="form-control"
              placeholder="Category"
              value={newCourse.category}
              onChange={(e) =>
                setNewCourse({ ...newCourse, category: e.target.value })
              }
            />
          </div>

          <div className="col-md-2">
            <input
              type="text"
              className="form-control"
              placeholder="₱0.00"
              style={{ width: '150px' }}
              value={newCourse.price}
              onChange={(e) => {
                let val = e.target.value.replace(/[^\d.]/g, '');
                const parts = val.split('.');
                val = parts[0].replace(/^0+(?!$)/, '');
                if (parts.length > 1) {
                  val += '.' + parts[1].slice(0, 2);
                }
                const formatted = val ? `₱${val}` : '';
                setNewCourse({ ...newCourse, price: formatted });
              }}
            />
          </div>

          <div className="col-md-3">
            <label htmlFor="fileInput" className="btn btn-outline-primary w-100 mb-2">
              Upload Image
            </label>
            <input
              type="file"
              id="fileInput"
              accept="image/*"
              style={{ display: 'none' }}
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  const imageUrl = URL.createObjectURL(file);
                  setNewCourse({ ...newCourse, image: imageUrl });
                  setNewImageName(file.name);
                }
              }}
            />
            {newImageName && (
              <div className="text-muted text-center small">Uploaded: {newImageName}</div>
            )}
          </div>

          <div className="col-md-2">
            <button className="btn btn-success w-100" onClick={handleAddCourse}>
              Add Course
            </button>
          </div>
        </div>
      </div>

      {/* Courses Section */}
      <div className="site-section">
        <div className="container">
          <div className="row">
            {courses.map((course) => (
              <div className="col-lg-4 col-md-6 mb-4" key={course.id}>
                <div className="course-1-item">
                  <figure className="thumbnail">
                    <img src={course.image} alt={course.title} className="img-fluid" />
                    <div className="price">{course.price}</div>
                    <div className="category">
                      <h3>{course.category}</h3>
                    </div>
                  </figure>

                  <div className="course-1-content pb-4">
                    {editCourseId === course.id ? (
                      <>
                        <input
                          type="text"
                          className="form-control mb-2"
                          placeholder="Title"
                          value={editedCourse.title}
                          onChange={(e) =>
                            setEditedCourse({ ...editedCourse, title: e.target.value })
                          }
                        />
                        <input
                          type="text"
                          className="form-control mb-2"
                          placeholder="Category"
                          value={editedCourse.category}
                          onChange={(e) =>
                            setEditedCourse({
                              ...editedCourse,
                              category: e.target.value,
                            })
                          }
                        />
                        <input
                          type="text"
                          className="form-control mb-2"
                          placeholder="₱0.00"
                          style={{ width: '150px' }}
                          value={editedCourse.price}
                          onChange={(e) => {
                            let val = e.target.value.replace(/[^\d.]/g, '');
                            const parts = val.split('.');
                            val = parts[0].replace(/^0+(?!$)/, '');
                            if (parts.length > 1) {
                              val += '.' + parts[1].slice(0, 2);
                            }
                            const formatted = val ? `₱${val}` : '';
                            setEditedCourse({ ...editedCourse, price: formatted });
                          }}
                        />
                        <div className="mb-2">
                          <label
                            htmlFor={`editFileInput-${course.id}`}
                            className="btn btn-outline-primary w-100 mb-2"
                          >
                            Upload New Image
                          </label>
                          <input
                            type="file"
                            id={`editFileInput-${course.id}`}
                            accept="image/*"
                            style={{ display: 'none' }}
                            onChange={(e) => {
                              const file = e.target.files[0];
                              if (file) {
                                const imageUrl = URL.createObjectURL(file);
                                setEditedCourse({ ...editedCourse, image: imageUrl });
                                setEditedImageNames((prev) => ({
                                  ...prev,
                                  [course.id]: file.name,
                                }));
                              }
                            }}
                          />
                          {editedImageNames[course.id] && (
                            <div className="text-muted text-center small">
                              Uploaded: {editedImageNames[course.id]}
                            </div>
                          )}
                        </div>

                        <div className="d-flex justify-content-between">
                          <button className="btn btn-success" onClick={handleSaveCourse}>
                            Save
                          </button>
                          <button className="btn btn-secondary" onClick={handleCancelEdit}>
                            Cancel
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <h2>{course.title}</h2>
                        <div className="rating text-center mb-3">
                          {[...Array(5)].map((_, i) => (
                            <span className="icon-star2 text-warning" key={i}></span>
                          ))}
                        </div>
                        <p className="desc mb-4">
                          Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        </p>
                        <div className="d-flex justify-content-between">
                          <Link to="/course-single" className="btn btn-primary rounded-0 px-3">
                            Enroll
                          </Link>
                          <button
                            className="btn btn-warning rounded-0 px-3"
                            onClick={() => handleEditCourse(course)}
                          >
                            Edit
                          </button>
                          <button
                            className="btn btn-danger rounded-0 px-3"
                            onClick={() => handleDeleteCourse(course.id)}
                          >
                            Delete
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {courses.length === 0 && (
              <p className="text-center">No courses available.</p>
            )}
          </div>
        </div>
      </div>
      <footer className="footer">
        <div className="container">
          <div className="row">
            <div className="col-lg-3">
              <p className="mb-4">
                <img src="/assets/images/logo.png" alt="Logo" className="img-fluid" />
              </p>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>
              <p><Link to="#">Learn More</Link></p>
            </div>
      
            <div className="col-lg-3">
              <h3 className="footer-heading"><span>Our Campus</span></h3>
              <ul className="list-unstyled">
                <li><Link to="#">Academic</Link></li>
                <li><Link to="#">News</Link></li>
                <li><Link to="#">Our Interns</Link></li>
                <li><Link to="#">Our Leadership</Link></li>
                <li><Link to="#">Careers</Link></li>
                <li><Link to="#">Human Resources</Link></li>
              </ul>
            </div>
      
            <div className="col-lg-3">
              <h3 className="footer-heading"><span>Our Courses</span></h3>
              <ul className="list-unstyled">
                <li><Link to="#">Math</Link></li>
                <li><Link to="#">Science & Engineering</Link></li>
                <li><Link to="#">Arts & Humanities</Link></li>
                <li><Link to="#">Economics & Finance</Link></li>
                <li><Link to="#">Business Administration</Link></li>
                <li><Link to="#">Computer Science</Link></li>
              </ul>
            </div>
      
            <div className="col-lg-3">
              <h3 className="footer-heading"><span>Contact</span></h3>
              <ul className="list-unstyled">
                <li><Link to="#">Help Center</Link></li>
                <li><Link to="#">Support Community</Link></li>
                <li><Link to="#">Press</Link></li>
                <li><Link to="#">Share Your Story</Link></li>
                <li><Link to="#">Our Supporters</Link></li>
              </ul>
            </div>
          </div>
      
          <div className="row">
            <div className="col-12">
              <div className="copyright text-center">
                <p>
                  &copy; {new Date().getFullYear()} All rights reserved | This template is made with{' '}
                  <i className="icon-heart" aria-hidden="true"></i> by{' '}
                  <a href="https://colorlib.com" target="_blank" rel="noopener noreferrer">Colorlib</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default AdminCourses;
