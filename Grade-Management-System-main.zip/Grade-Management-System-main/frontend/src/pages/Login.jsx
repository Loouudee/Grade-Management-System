import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const res = await fetch('http://localhost:4000/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok) {
        // Store the token in localStorage for session tracking
        localStorage.setItem('token', data.token);
        navigate('/dashboard'); // or wherever the user should go
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    }
  };


  return (
    <>
      <div className="site-wrap">
        {/* Mobile Menu */}
        <div className="site-mobile-menu site-navbar-target">
          <div className="site-mobile-menu-header">
            <div className="site-mobile-menu-close mt-3">
              <span className="icon-close2 js-menu-toggle"></span>
            </div>
          </div>
          <div className="site-mobile-menu-body" />
        </div>

        {/* Top Bar */}
        <div className="py-2 bg-light">
          <div className="container">
            <div className="row align-items-center">
              <div className="col-lg-9 d-none d-lg-block">
                <Link to="#" className="small mr-3">
                  <span className="icon-question-circle-o mr-2"></span> Have a question?
                </Link>
                <Link to="#" className="small mr-3">
                  <span className="icon-phone2 mr-2"></span> 10 20 123 456
                </Link>
                <Link to="#" className="small mr-3">
                  <span className="icon-envelope-o mr-2"></span> info@mydomain.com
                </Link>
              </div>
              <div className="col-lg-3 text-right">
                <Link to="/login" className="small mr-3">
                  <span className="icon-unlock-alt"></span> Log In
                </Link>
                <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                  <span className="icon-users"></span> Register
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Header/Navbar with inline background fix */}
      <header
  className="site-navbar py-4 site-navbar-target"
  role="banner"
  style={{ backgroundColor: 'white' }} // removed: position, zIndex, width
>
  <div className="container">
    <div className="row align-items-center">
      <div className="col-6 col-xl-2">
        <h1 className="mb-0 site-logo">
          <Link to="/" className="text-black h2 mb-0">
            Academics<span className="text-primary">.</span>
          </Link>
        </h1>
      </div>

      <div className="col-12 col-md-10 d-none d-xl-block">
        <nav className="site-navigation position-relative text-right" role="navigation">
          <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
            <li><Link to="/" className="nav-link">Home</Link></li>
            <li><Link to="/about" className="nav-link">About</Link></li>
            <li><Link to="/courses" className="nav-link">Courses</Link></li>
            <li><Link to="/contact" className="nav-link">Contact</Link></li>
          </ul>
        </nav>
      </div>

      <div className="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style={{ position: 'relative', top: '3px' }}>
        <a href="#" className="site-menu-toggle js-menu-toggle text-black">
          <span className="icon-menu h3" />
        </a>
      </div>
    </div>
  </div>
</header>


      {/* Hero Section with Padding to Avoid Overlap */}
      <div
        className="site-section-cover overlay inner-page bg-light"
        style={{
            backgroundImage: `url('/assets/images/bg_1.jpg')`,
            paddingTop: '150px',
            paddingBottom: '50px',
            backgroundSize: 'cover',
            backgroundPosition: 'center center',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            color: 'white'  // 👈 Makes all text inside white
        }}
        >
        <div className="container text-center">
            <div className="row justify-content-center">
            <div className="col-md-10">
                <h1 className="mb-2">Log In</h1>
                <div>
                <Link to="/" style={{ color: 'white' }}>Home</Link>{' '}
                <span className="mx-2">&gt;</span>{' '}
                <span style={{ color: 'white' }}>Log In</span>
                </div>
            </div>
            </div>
        </div>
        </div>
        <div className="site-section">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-md-5">
              <form onSubmit={handleSubmit} className="bg-white p-5 contact-form">
                {error && <div className="alert alert-danger">{error}</div>}
                <div className="form-group">
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <input
                    type="submit"
                    value="Log In"
                    className="btn btn-primary py-2 px-4 text-white"
                  />
                </div>
                <div className="form-group d-flex justify-content-between">
                  <label className="mb-0">
                    <input type="checkbox" className="mr-2" /> Remember Me
                  </label>
                  <Link to="#" className="text-primary">Forgot Password?</Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
<footer className="footer">
  <div className="container">
    <div className="row">
      <div className="col-lg-3">
        <p className="mb-4">
          <img src="/assets/images/logo.png" alt="Logo" className="img-fluid" />
        </p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>
        <p><Link to="#">Learn More</Link></p>
      </div>

      <div className="col-lg-3">
        <h3 className="footer-heading"><span>Our Campus</span></h3>
        <ul className="list-unstyled">
          <li><Link to="#">Academic</Link></li>
          <li><Link to="#">News</Link></li>
          <li><Link to="#">Our Interns</Link></li>
          <li><Link to="#">Our Leadership</Link></li>
          <li><Link to="#">Careers</Link></li>
          <li><Link to="#">Human Resources</Link></li>
        </ul>
      </div>

      <div className="col-lg-3">
        <h3 className="footer-heading"><span>Our Courses</span></h3>
        <ul className="list-unstyled">
          <li><Link to="#">Math</Link></li>
          <li><Link to="#">Science &amp; Engineering</Link></li>
          <li><Link to="#">Arts &amp; Humanities</Link></li>
          <li><Link to="#">Economics &amp; Finance</Link></li>
          <li><Link to="#">Business Administration</Link></li>
          <li><Link to="#">Computer Science</Link></li>
        </ul>
      </div>

      <div className="col-lg-3">
        <h3 className="footer-heading"><span>Contact</span></h3>
        <ul className="list-unstyled">
          <li><Link to="#">Help Center</Link></li>
          <li><Link to="#">Support Community</Link></li>
          <li><Link to="#">Press</Link></li>
          <li><Link to="#">Share Your Story</Link></li>
          <li><Link to="#">Our Supporters</Link></li>
        </ul>
      </div>
    </div>

    <div className="row">
      <div className="col-12">
        <div className="copyright text-center">
          <p>
            &copy; {new Date().getFullYear()} All rights reserved | This template is made with 
            <i className="icon-heart" aria-hidden="true"></i> by 
            <a href="https://colorlib.com" target="_blank" rel="noopener noreferrer"> Colorlib</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</footer>

    </>
  );
};

export default Login;
