import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const CourseSingleEdit = () => {
  const [courseData, setCourseData] = useState({
    title: "How To Create Mobile Apps Using Ionic",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    teacher: "Craig Daniel",
    hours: "8:00 am — 9:30 am",
    details: [
      "Lorem ipsum dolor sit amet consectetur",
      "consectetur adipisicing",
      "Sit dolor repellat esse",
      "Necessitatibus",
      "Sed necessitatibus itaque",
    ],
    longDescription: `Lorem ipsum dolor sit amet consectetur adipisicing elit. At itaque dolore libero corrupti! Itaque, delectus?\nModi sit dolor repellat esse! Sed necessitatibus itaque libero odit placeat nesciunt, voluptatum totam facere.`,
    image: "/assets/images/course_5.jpg",
    imageName: "",
  });

  const handleFieldChange = (field, value) => {
    setCourseData({ ...courseData, [field]: value });
  };

  const handleDetailChange = (index, value) => {
    const updatedDetails = [...courseData.details];
    updatedDetails[index] = value;
    setCourseData({ ...courseData, details: updatedDetails });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setCourseData({ ...courseData, image: imageUrl, imageName: file.name });
    }
  };

  return (
    <>
      {/* Breadcrumbs + Hero */}
      <div
        className="site-section ftco-subscribe-1 site-blocks-cover pb-4"
        style={{
          backgroundImage: "url('/assets/images/bg_1.jpg')",
          marginTop: '8rem',
          paddingTop: '2rem',
          paddingBottom: '2rem'
        }}
      >
        <div className="container">
          <div className="row align-items-end">
            <div className="col-lg-7">
              <input
                type="text"
                className="form-control h2 mb-2"
                value={courseData.title}
                onChange={(e) => handleFieldChange('title', e.target.value)}
              />
              <textarea
                className="form-control"
                rows="2"
                value={courseData.description}
                onChange={(e) => handleFieldChange('description', e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Course Content */}
      <div className="site-section">
        <div className="container">
          <div className="row">
            <div className="col-md-6 mb-4">
              <p>
                <img src={courseData.image} alt="Course" className="img-fluid" />
              </p>
              <label htmlFor="imageUpload" className="btn btn-outline-primary btn-sm mb-2 w-100">
                Upload New Image
              </label>
              <input
                type="file"
                id="imageUpload"
                style={{ display: "none" }}
                accept="image/*"
                onChange={handleImageUpload}
              />
              {courseData.imageName && (
                <div className="text-muted text-center small">
                  Uploaded: {courseData.imageName}
                </div>
              )}
            </div>

            <div className="col-lg-5 ml-auto align-self-center">
              <h2 className="section-title-underline mb-4">
                <span>Course Details</span>
              </h2>

              <p>
                <strong className="text-black d-block">Teacher:</strong>
                <input
                  type="text"
                  className="form-control"
                  value={courseData.teacher}
                  onChange={(e) => handleFieldChange('teacher', e.target.value)}
                />
              </p>

              <p className="mb-4">
                <strong className="text-black d-block">Hours:</strong>
                <input
                  type="text"
                  className="form-control"
                  value={courseData.hours}
                  onChange={(e) => handleFieldChange('hours', e.target.value)}
                />
              </p>

              <textarea
                className="form-control mb-3"
                rows="4"
                value={courseData.longDescription}
                onChange={(e) => handleFieldChange('longDescription', e.target.value)}
              />

              <ul className="ul-check primary list-unstyled mb-4">
                {courseData.details.map((item, index) => (
                  <li key={index}>
                    <input
                      type="text"
                      className="form-control mb-1"
                      value={item}
                      onChange={(e) => handleDetailChange(index, e.target.value)}
                    />
                  </li>
                ))}
              </ul>

              <div className="d-flex gap-2">
                <button className="btn btn-success btn-lg rounded-0 mr-2">Save Changes</button>
                <button className="btn btn-secondary btn-lg rounded-0">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CourseSingleEdit;
