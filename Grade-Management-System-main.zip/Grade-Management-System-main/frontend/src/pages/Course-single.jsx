import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import axios from 'axios';

const CourseSingle = () => {
  const { id } = useParams(); // Get the course ID from the URL
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/courses/${id}`);
        setCourse(response.data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchCourse();
  }, [id]);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  if (!course) {
    return <p>Course not found.</p>;
  }

  return (
    <>
      {/* Top Bar */}
      <div className="py-2 bg-light">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-9 d-none d-lg-block">
              <Link to="#" className="small mr-3">
                <span className="icon-question-circle-o mr-2"></span> Have a question?
              </Link>
              <Link to="#" className="small mr-3">
                <span className="icon-phone2 mr-2"></span> 10 20 123 456
              </Link>
              <Link to="#" className="small mr-3">
                <span className="icon-envelope-o mr-2"></span> info@mydomain.com
              </Link>
            </div>
            <div className="col-lg-3 text-right">
              <Link to="/login" className="small mr-3">
                <span className="icon-unlock-alt"></span> Log In
              </Link>
              <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                <span className="icon-users"></span> Register
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Header/Navbar */}
      <header className="site-navbar py-4 site-navbar-target" role="banner">
        <div className="container">
          <div className="d-flex align-items-center">
            <div className="site-logo">
              <Link to="/" className="d-block">
                <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
              </Link>
            </div>
            <div className="mr-auto">
              <nav className="site-navigation position-relative text-right" role="navigation">
                <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                  <li className="active">
                    <Link to="/" className="nav-link text-left">Home</Link>
                  </li>
                  <li><Link to="/admissions" className="nav-link text-left">Admissions</Link></li>
                  <li><Link to="/courses" className="nav-link text-left">Courses</Link></li>
                  <li><Link to="/contact" className="nav-link text-left">Contact</Link></li>
                </ul>
              </nav>
            </div>
            <div className="ml-auto">
              <div className="social-wrap">
                <Link to="#"><span className="icon-facebook" /></Link>
                <Link to="#"><span className="icon-twitter" /></Link>
                <Link to="#"><span className="icon-linkedin" /></Link>
                <Link to="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
                  <span className="icon-menu h3" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="site-section ftco-subscribe-1 site-blocks-cover pb-4"
        style={{
          backgroundImage: "url('/assets/images/bg_1.jpg')",
          marginTop: '8rem',
          paddingTop: '2rem',
          paddingBottom: '2rem'
        }}
      >
        <div className="container">
          <div className="row align-items-end">
            <div className="col-lg-7">
              <h2 className="mb-0">{course.name}</h2>
              <p>{course.description}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumbs */}
      <div className="custom-breadcrumns border-bottom">
        <div className="container">
          <Link to="/">Home</Link>
          <span className="mx-3 icon-keyboard_arrow_right"></span>
          <Link to="/courses">Courses</Link>
          <span className="mx-3 icon-keyboard_arrow_right"></span>
          <span className="current">Courses</span>
        </div>
      </div>

      {/* Course Details Section */}
      <div className="site-section">
        <div className="container">
          <div className="row">
            <div className="col-md-6 mb-4">
              <p>
                <img src={course.image} alt="Course" className="img-fluid" />
              </p>
            </div>
            <div className="col-lg-5 ml-auto align-self-center">
              <h2 className="section-title-underline mb-5">
                <span>Course Details</span>
              </h2>

              <p>
                <strong className="text-black d-block">Teacher:</strong> {course.teacher}
              </p>
              <p className="mb-5">
                <strong className="text-black d-block">Hours:</strong> {course.schedule}
              </p>
              <p>{course.details}</p>

              <ul className="ul-check primary list-unstyled mb-5">
                {course.benefits.map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))}
              </ul>

              <p>
                <Link to="#" className="btn btn-primary rounded-0 btn-lg px-5">
                  Enroll
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>

    </>
  );
};

export default CourseSingle;
