import React from 'react';

const StudentPage = () => {
  return (
    <div>
      <h1>Welcome, Student!</h1>
      <p>This page is only accessible by students.</p>
    </div>
  );
};

export default StudentPage;
