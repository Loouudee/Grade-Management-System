import React, { useEffect } from 'react';

const HomePage = () => {
  useEffect(() => {
    const loadScripts = () => {
      const scripts = [
        '/assets/js/jquery-3.3.1.min.js',
        '/assets/js/jquery-migrate-3.0.1.min.js',
        '/assets/js/jquery-ui.js',
        '/assets/js/popper.min.js',
        '/assets/js/bootstrap.min.js',
        '/assets/js/owl.carousel.min.js',
        '/assets/js/jquery.stellar.min.js',
        '/assets/js/jquery.countdown.min.js',
        '/assets/js/bootstrap-datepicker.min.js',
        '/assets/js/jquery.easing.1.3.js',
        '/assets/js/aos.js',
        '/assets/js/jquery.fancybox.min.js',
        '/assets/js/jquery.sticky.js',
        '/assets/js/jquery.mb.YTPlayer.min.js',
        '/assets/js/main.js'
      ];
  
      let loaded = 0;
      scripts.forEach(src => {
        const script = document.createElement('script');
        script.src = src;
        script.async = false;
        script.onload = () => {
          loaded++;
          if (loaded === scripts.length) {
            // ✅ Initialize Owl Carousel AFTER all scripts are loaded
            if (window.$ && window.$('.hero-slide').owlCarousel) {
              window.$('.hero-slide').owlCarousel({
                items: 1,
                loop: true,
                autoplay: true,
                autoplayTimeout: 5000,
                nav: false,
                dots: true
              });
            }
          }
        };
        document.body.appendChild(script);
      });
    };
  
    if (document.readyState === 'complete') {
      loadScripts();
    } else {
      window.addEventListener('load', loadScripts);
    }
  
    return () => window.removeEventListener('load', loadScripts);
  }, []);
  

  return (
  <>
  
  <div className="py-2 bg-light">
    <div className="container">
      <div className="row align-items-center">
        <div className="col-lg-9 d-none d-lg-block">
          <a href="#" className="small mr-3"><span className="icon-question-circle-o mr-2"></span> Have a questions?</a>
          <a href="#" className="small mr-3"><span className="icon-phone2 mr-2"></span> 10 20 123 456</a>
          <a href="#" className="small mr-3"><span className="icon-envelope-o mr-2"></span> info@mydomain.com</a>
        </div>
        <div className="col-lg-3 text-right">
          <a href="/login" className="small mr-3"><span className="icon-unlock-alt"></span> Log In</a>
          <a href="/register" className="small btn btn-primary px-4 py-2 rounded-0"><span className="icon-users"></span> Register</a>
        </div>
      </div>
    </div>
  </div>
  <header className="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
    <div className="container">
      <div className="d-flex align-items-center">
        <div className="site-logo">
          <a href="/" className="d-block">
            <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
          </a>
        </div>
        <div className="mr-auto">
          <nav className="site-navigation position-relative text-right" role="navigation">
            <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
              <li className="active">
                <a href="/" className="nav-link text-left">Home</a>
              </li>

              <li>
                <a href="/admissions" className="nav-link text-left">Admissions</a>
              </li>
              <li>
                <a href="/courses" className="nav-link text-left">All Courses</a>
              </li>
              <li>
                <a href="/mycourses" className="nav-link text-left">My Courses</a>
              </li>
              <li>
                <a href="/grades" className="nav-link text-left">My Grades</a>
              </li>
              <li>
                <a href="/contact" className="nav-link text-left">Contact</a>
              </li>
            </ul>
          </nav>
        </div>
        <div className="ml-auto">
          <div className="social-wrap">
            <a href="#"><span className="icon-facebook" /></a>
            <a href="#"><span className="icon-twitter" /></a>
            <a href="#"><span className="icon-linkedin" /></a>
            <a href="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
              <span className="icon-menu h3" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </header>
  <div className="hero-slide owl-carousel site-blocks-cover">
    <div
      className="intro-section"
      style={{
        backgroundImage: "url('/assets/images/hero_1.jpg')",
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center center'
      }}
    >
      <div className="container">
        <div className="row align-items-center">
          <div className="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1>Academics University</h1>
          </div>
        </div>
      </div>
    </div>

    <div
      className="intro-section"
      style={{
        backgroundImage: "url('/assets/images/hero_1.jpg')",
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center center'
      }}
    >
      <div className="container">
        <div className="row align-items-center">
          <div className="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1>You Can Learn Anything</h1>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div className="site-section">
    <div className="container">
      <div className="row mb-5 justify-content-center text-center">
        <div className="col-lg-4 mb-5">
          <h2 className="section-title-underline mb-5">
            <span>Why Academics Works</span>
          </h2>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-4 col-md-6 mb-4 mb-lg-0">
          <div className="feature-1 border">
            <div className="icon-wrapper bg-primary">
              <span className="flaticon-mortarboard text-white"></span>
            </div>
            <div className="feature-1-content">
              <h2>Personalize Learning</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi hendrerit elit</p>
              
            </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-6 mb-4 mb-lg-0">
          <div className="feature-1 border">
            <div className="icon-wrapper bg-primary">
              <span className="flaticon-school-material text-white"></span>
            </div>
            <div className="feature-1-content">
              <h2>Trusted Courses</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi hendrerit elit</p>
              
            </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-6 mb-4 mb-lg-0">
          <div className="feature-1 border">
            <div className="icon-wrapper bg-primary">
              <span className="flaticon-library text-white"></span>
            </div>
            <div className="feature-1-content">
              <h2>Tools for Students</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi hendrerit elit</p>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
  <div className="site-section">
    <div className="container">
      <div className="row mb-5 justify-content-center text-center">
        <div className="col-lg-6 mb-5">
          <h2 className="section-title-underline mb-3">
            <span>Popular Courses</span>
          </h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, id?</p>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="owl-slide-3 owl-carousel">
            {[1, 2, 3, 4, 5, 6].map((num) => (
              <div className="course-1-item" key={num}>
                <figure className="thumnail">
                  <a href="/course-single">
                    <img
                      src={`/assets/images/course_${num}.jpg`}
                      alt={`Course ${num}`}
                      className="img-fluid"
                    />
                  </a>
                  <div className="price">$99.00</div>
                  <div className="category">
                    <h3>
                      {num === 3 ? "Arithmetic" : num % 2 === 0 ? "Web Design" : "Mobile Application"}
                    </h3>
                  </div>
                </figure>
                <div className="course-1-content pb-4">
                  <h2>How To Create Mobile Apps Using Ionic</h2>
                  <div className="rating text-center mb-3">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="icon-star2 text-warning" />
                    ))}
                  </div>
                  <p className="desc mb-4">
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Similique accusantium
                    ipsam.
                  </p>
                  <p>
                    <a href="/course-single" className="btn btn-primary rounded-0 px-4">
                      Enroll In This Course
                    </a>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
  
  

  
  <div
  className="section-bg style-1"
  style={{ backgroundImage: "url('/assets/images/about_1.jpg')" }}
  >
    <div className="container">
      <div className="row">
        <div className="col-lg-4">
          <h2 className="section-title-underline style-2">
            <span>About Our University</span>
          </h2>
        </div>
        <div className="col-lg-8">
          <p className="lead">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rem nesciunt
            quaerat ad reiciendis perferendis voluptate fugiat sunt fuga error totam.
          </p>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus
            assumenda omnis tempora ullam alias amet eveniet voluptas, incidunt quasi
            aut officiis porro ad, expedita saepe necessitatibus rem debitis architecto
            dolore? Nam omnis sapiente placeat blanditiis voluptas dignissimos, itaque
            fugit a laudantium adipisci dolorem enim ipsum cum molestias? Quod quae
            molestias modi fugiat quisquam. Eligendi recusandae officiis debitis quas
            beatae aliquam?
          </p>
        </div>
      </div>
    </div>
  </div>

  <div className="site-section">
  <div className="container">
    <div className="row mb-5">
      <div className="col-lg-4">
        <h2 className="section-title-underline">
          <span>Testimonials</span>
        </h2>
      </div>
    </div>

    <div className="owl-slide owl-carousel">
      {[1, 2, 4, 3, 2, 4].map((num, index) => (
        <div className="ftco-testimonial-1" key={index}>
          <div className="ftco-testimonial-vcard d-flex align-items-center mb-4">
            <img
              src={`/assets/images/person_${num}.jpg`}
              alt={`Testimonial ${index + 1}`}
              className="img-fluid mr-3"
            />
            <div>
              <h3>Allison Holmes</h3>
              <span>Designer</span>
            </div>
          </div>
          <div>
            <p>
              &ldquo;Lorem ipsum dolor sit, amet consectetur adipisicing elit. Neque, mollitia.
              Possimus mollitia nobis libero quidem aut tempore dolore iure maiores, perferendis,
              provident numquam illum nisi amet necessitatibus. A, provident aperiam!&rdquo;
            </p>
          </div>
        </div>
      ))}
    </div>
  </div>
</div>

  
  

  </>
   
  

  );
};

export default HomePage;
