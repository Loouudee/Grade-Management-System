import './scss/style.scss'; // Adjust this if your SCSS is elsewhere
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import Login from './pages/Login';
import Register from './pages/Register';
import Courses from './pages/Courses';
import CourseSingle from './pages/Course-single';
import Admissions from './pages/Admissions';
import Grades from './pages/Grades';
import AdminGrades from './pages/Admin-Grades';
import AdminCourses from './pages/Admin-courses';
import CourseSingleEdit from './pages/CourseSingleEdit';
import MyCourses from './pages/MyCourses';
import MyCourseSingle from './pages/MyCourse-single';
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />

        {/* Visitor's View */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admissions" element={<Admissions />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/courses-single/:id" element={<CourseSingle />} />



        {/* Admin View */}
        <Route path="/admin-courses" element={<AdminCourses />} />
        <Route path="/admin-course-single" element={<CourseSingleEdit />} />
        <Route path="/admin-grades" element={<AdminGrades />} />
        
        {/* Student View */}
        <Route path="/grades" element={<Grades />} />
        <Route path="/mycourses" element={<MyCourses />} />
        <Route path="/mycourse-single" element={<MyCourseSingle />} />
      </Routes>
    </Router>
  );
}

export default App;