const mongoose = require('mongoose');
const AUTH_DB = 'mongodb://localhost:27017/auth-service';
const COURSE_DB = 'mongodb://localhost:27018/course-service';

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  role: String,
});

const courseSchema = new mongoose.Schema({
  title: String,
  courseCode: String,
  description: String,
  faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  enrolledStudents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  startTime: { type: String, required: true },  // Added startTime
  endTime: { type: String, required: true },    // Added endTime
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
const Course = mongoose.model('Course', courseSchema);

const seedCourses = async () => {
  const authConnection = mongoose.createConnection(AUTH_DB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  await new Promise((resolve, reject) => {
    authConnection.once('open', resolve);
    authConnection.on('error', reject);
  });

  const courseConnection = mongoose.createConnection(COURSE_DB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  await new Promise((resolve, reject) => {
    courseConnection.once('open', resolve);
    courseConnection.on('error', reject);
  });

  const AuthUser = authConnection.model('User', userSchema);
  const CourseModel = courseConnection.model('Course', courseSchema);

  const faculties = await AuthUser.find({ role: 'faculty' });

  if (faculties.length < 5) {
    console.error('Need at least 5 faculty members. Please run seedUsers.js first.');
    return;
  }

  const courses = [
    {
      title: 'Mobile Development',
      courseCode: 'MOBDEVE',
      description: 'Learn to develop mobile apps for Android and iOS.',
      startTime: '09:00 AM',
      endTime: '11:00 AM',
      faculty: faculties[0]._id,
      enrolledStudents: [], // Empty array or can be populated later
    },
    {
      title: 'Web Development',
      courseCode: 'CCAPDEV',
      description: 'Introduction to web technologies, including HTML, CSS, and JavaScript.',
      startTime: '11:00 AM',
      endTime: '01:00 PM',
      faculty: faculties[1]._id,
      enrolledStudents: [], // Empty array or can be populated later
    },
    {
      title: 'Computer Architecture 1',
      courseCode: 'CSARCH1',
      description: 'Foundations of computer architecture, including CPU, memory, and I/O systems.',
      startTime: '02:00 PM',
      endTime: '04:00 PM',
      faculty: faculties[2]._id,
      enrolledStudents: [], // Empty array or can be populated later
    },
    {
      title: 'Computer Architecture 2',
      courseCode: 'CSARCH2',
      description: 'Advanced topics in computer architecture such as pipelining and parallel processing.',
      startTime: '04:00 PM',
      endTime: '06:00 PM',
      faculty: faculties[3]._id,
      enrolledStudents: [], // Empty array or can be populated later
    },
    {
      title: 'Operating Systems',
      courseCode: 'CSOPESY',
      description: 'Study of modern operating systems, processes, memory management, and file systems.',
      startTime: '06:00 PM',
      endTime: '08:00 PM',
      faculty: faculties[4]._id,
      enrolledStudents: [], // Empty array or can be populated later
    },
  ];

  await CourseModel.deleteMany(); // Optional: clear courses first
  const inserted = await CourseModel.insertMany(courses);

  console.log('Courses seeded:', inserted);
  await authConnection.close();
  await courseConnection.close();
};

seedCourses();
