const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const MONGO_URI = 'mongodb://localhost:27017/auth-service';

const User = require('./models/userModel');

const seedUsers = async () => {
  await mongoose.connect(MONGO_URI);
  await User.deleteMany(); // Optional: Clears existing users

  const hashedPassword = await bcrypt.hash('password123', 10);

  const students = Array.from({ length: 5 }, (_, i) => ({
    username: `Student ${i + 1}`,
    email: `student${i + 1}@mail.com`,
    password: hashedPassword,
    role: 'student',
  }));

  const faculties = Array.from({ length: 5 }, (_, i) => ({
    username: `Faculty ${i + 1}`,
    email: `faculty${i + 1}@mail.com`,
    password: hashedPassword,
    role: 'faculty',
  }));

  const users = [...students, ...faculties];

  const inserted = await User.insertMany(users);
  console.log('Users seeded:', inserted.map(u => u.email));
  mongoose.disconnect();
};

seedUsers();
