import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/courses'); // 🔁 update with your actual endpoint
        setCourses(response.data);
      } catch (error) {
        console.error('Error fetching courses:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);
  return (
    <>
      {/* Top Bar */}
      <div className="py-2 bg-light">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-9 d-none d-lg-block">
              <Link to="#" className="small mr-3">
                <span className="icon-question-circle-o mr-2"></span> Have a question?
              </Link>
              <Link to="#" className="small mr-3">
                <span className="icon-phone2 mr-2"></span> 10 20 123 456
              </Link>
              <Link to="#" className="small mr-3">
                <span className="icon-envelope-o mr-2"></span> info@mydomain.com
              </Link>
            </div>
            <div className="col-lg-3 text-right">
              <Link to="/login" className="small mr-3">
                <span className="icon-unlock-alt"></span> Log In
              </Link>
              <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                <span className="icon-users"></span> Register
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Header/Navbar */}
      <header className="site-navbar py-4 site-navbar-target" role="banner">
        <div className="container">
          <div className="d-flex align-items-center">
            <div className="site-logo">
              <Link to="/" className="d-block">
                <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
              </Link>
            </div>
            <div className="mr-auto">
              <nav className="site-navigation position-relative text-right" role="navigation">
                <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                  <li className="active">
                    <Link to="/" className="nav-link text-left">Home</Link>
                  </li>
                  
                  <li><Link to="/admissions" className="nav-link text-left">Admissions</Link></li>
                  <li><Link to="/courses" className="nav-link text-left">Courses</Link></li>
                  <li><Link to="/contact" className="nav-link text-left">Contact</Link></li>
                </ul>
              </nav>
            </div>
            <div className="ml-auto">
              <div className="social-wrap">
                <Link to="#"><span className="icon-facebook" /></Link>
                <Link to="#"><span className="icon-twitter" /></Link>
                <Link to="#"><span className="icon-linkedin" /></Link>
                <Link to="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
                  <span className="icon-menu h3" />
                </Link>
              </div>
            </div>
          </div>
        </div>
    </header>
    {/* Hero Section */}
    <div
    className="site-section ftco-subscribe-1 site-blocks-cover pb-4"
    style={{
        backgroundImage: "url('/assets/images/hero_1.jpg')",
        marginTop: '8rem', // or 8rem, 10rem depending on what you want
        paddingTop: '5rem', // optional: if you want more inner space
    }}
    >
        <div className="container">
            <div className="row align-items-end">
            <div className="col-lg-7">
                <h2 className="mb-0">Courses</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            </div>
            </div>
        </div>
    </div>

    {/* Breadcrumbs */}
    <div className="custom-breadcrumns border-bottom">
        <div className="container">
            <Link to="/">Home</Link>
            <span className="mx-3 icon-keyboard_arrow_right"></span>
            <span className="current">Courses</span>
        </div>
    </div>


    
    {/* Popular Courses Section */}
    {/* Courses Grid */}
    {/* Courses Section */}
    <div className="site-section">
        <div className="container">
          <div className="row">
            {loading ? (
              <div className="col-12 text-center">
                <p>Loading courses...</p>
              </div>
            ) : courses.length === 0 ? (
              <div className="col-12 text-center">
                <p>No courses found.</p>
              </div>
            ) : (
              courses.map((course, index) => (
                <div className="col-lg-4 col-md-6 mb-4" key={course._id}>
                  <div className="course-1-item">
                    <figure className="thumbnail">
                      <Link to={`/courses/${course._id}`}>
                        <img
                          src={`/assets/images/course_${(index % 6) + 1}.jpg`} // rotate 1–6
                          alt={`Course ${course.title}`}
                          className="img-fluid"
                        />
                      </Link>
                      <div className="price">$99.00</div>
                      <div className="category">
                        <h3>{course.courseCode}</h3>
                      </div>
                    </figure>
                    <div className="course-1-content pb-4">
                      <h2>{course.title}</h2>
                      <div className="rating text-center mb-3">
                        {[...Array(5)].map((_, i) => (
                          <span className="icon-star2 text-warning" key={i}></span>
                        ))}
                      </div>
                      <p className="desc mb-4">{"You should take this class"}</p>
                      <p>
                        <Link to={`/courses-single/${course._id}`} className="btn btn-primary rounded-0 px-4">
                          View Details
                        </Link>
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

    {/* Footer */}
    <div className="footer">
        <div className="container">
            <div className="row">
            <div className="col-lg-3">
                <p className="mb-4">
                <img src="/assets/images/logo.png" alt="Logo" className="img-fluid" />
                </p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>
                <p><Link to="#">Learn More</Link></p>
            </div>
            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Campus</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Academic</Link></li>
                <li><Link to="#">News</Link></li>
                <li><Link to="#">Our Interns</Link></li>
                <li><Link to="#">Our Leadership</Link></li>
                <li><Link to="#">Careers</Link></li>
                <li><Link to="#">Human Resources</Link></li>
                </ul>
            </div>
            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Courses</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Math</Link></li>
                <li><Link to="#">Science &amp; Engineering</Link></li>
                <li><Link to="#">Arts &amp; Humanities</Link></li>
                <li><Link to="#">Economics &amp; Finance</Link></li>
                <li><Link to="#">Business Administration</Link></li>
                <li><Link to="#">Computer Science</Link></li>
                </ul>
            </div>
            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Contact</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Help Center</Link></li>
                <li><Link to="#">Support Community</Link></li>
                <li><Link to="#">Press</Link></li>
                <li><Link to="#">Share Your Story</Link></li>
                <li><Link to="#">Our Supporters</Link></li>
                </ul>
            </div>
            </div>

            <div className="row">
            <div className="col-12">
                <div className="copyright">
                <p>
                    &copy; {new Date().getFullYear()} All rights reserved | This template is made with <i className="icon-heart" aria-hidden="true"></i> by{' '}
                    <a href="https://colorlib.com" target="_blank" rel="noopener noreferrer">Colorlib</a>
                </p>
                </div>
            </div>
            </div>
        </div>
    </div>
       
    

            


    </>
  );
};

export default Courses;
