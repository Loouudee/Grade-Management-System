import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {jwtDecode} from 'jwt-decode'; // Import jwt-decode

const ProtectedRoute = ({ role, children }) => {
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    try {
      // Decode the token using jwt-decode
      const decodedToken = jwtDecode(token);
      const userRole = decodedToken.role;

    console.log("USER ROLE")
      console.log(decodedToken)

      if (!userRole || userRole !== role) {
        navigate('/unauthorized'); // Redirect to unauthorized page if the role doesn't match
      } else {
        setLoading(false); // Show the page content if role matches
      }
    } catch (error) {
      console.error("Token decoding error: ", error);
      navigate('/login'); // Redirect to login if token is invalid or expired
    }
  }, [navigate, role]);

  if (loading) return <div>Loading...</div>;

  return <>{children}</>;
};

export default ProtectedRoute;
