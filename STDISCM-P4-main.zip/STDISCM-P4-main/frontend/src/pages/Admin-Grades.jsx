import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Grades = () => {
  const initialData = [
    { id: 1, name: 'Dakota Rice', salary: '$36,738', country: 'Niger', city: 'Oud-Turnhout' },
    { id: 2, name: 'Minerva Hooper', salary: '$23,789', country: 'Curaçao', city: 'Sinaai-Waas' },
    { id: 3, name: 'Sage Rodriguez', salary: '$56,142', country: 'Netherlands', city: 'Baileux' },
    { id: 4, name: 'Philip Chaney', salary: '$38,735', country: 'Korea, South', city: 'Overland Park' },
    { id: 5, name: 'Doris Greene', salary: '$63,542', country: 'Malawi', city: 'Feldkirchen in Kärnten' }
  ];

  const [data, setData] = useState(initialData);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'ascending' });
  const [currentPage, setCurrentPage] = useState(1);
  const [editRowId, setEditRowId] = useState(null);
  const [editFormData, setEditFormData] = useState({});

  const pageSize = 10;

  const handleSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const sortedData = [...data].sort((a, b) => {
    if (!sortConfig.key) return 0;
    const aVal = a[sortConfig.key].toString().toLowerCase();
    const bVal = b[sortConfig.key].toString().toLowerCase();
    if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
    if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
    return 0;
  });

  const filteredData = sortedData.filter((row) =>
    Object.values(row).some(val =>
      val.toString().toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const totalPages = Math.ceil(filteredData.length / pageSize);
  const paginatedData = filteredData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const renderSortArrow = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'ascending' ? ' 🔼' : ' 🔽';
  };

  const handleEditClick = (row) => {
    setEditRowId(row.id);
    setEditFormData({ ...row });
  };

  const handleCancelEdit = () => {
    setEditRowId(null);
    setEditFormData({});
  };

  const handleSaveEdit = () => {
    setData((prevData) =>
      prevData.map((row) => (row.id === editRowId ? { ...editFormData } : row))
    );
    setEditRowId(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prev) => ({ ...prev, [name]: value }));
  };
  const handleDelete = (row) => {
    const updated = data.filter((item) => item.id !== row.id);
    setData(updated);
  
    // Adjust page if needed (e.g., last item removed)
    const newTotalPages = Math.ceil(updated.length / pageSize);
    if (currentPage > newTotalPages) {
      setCurrentPage(newTotalPages);
    }
  };
  

  return (
    <>
        {/* Top Bar */}
        <div className="py-2 bg-light">
            <div className="container">
            <div className="row align-items-center">
                <div className="col-lg-9 d-none d-lg-block">
                <Link to="#" className="small mr-3">
                    <span className="icon-question-circle-o mr-2"></span> Have a question?
                </Link>
                <Link to="#" className="small mr-3">
                    <span className="icon-phone2 mr-2"></span> 10 20 123 456
                </Link>
                <Link to="#" className="small mr-3">
                    <span className="icon-envelope-o mr-2"></span> info@mydomain.com
                </Link>
                </div>
                <div className="col-lg-3 text-right">
                <Link to="/login" className="small mr-3">
                    <span className="icon-unlock-alt"></span> Log In
                </Link>
                <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                    <span className="icon-users"></span> Register
                </Link>
                </div>
            </div>
            </div>
        </div>
    
        {/* Header/Navbar */}
        <header className="site-navbar py-4 site-navbar-target" role="banner">
            <div className="container">
                <div className="d-flex align-items-center">
                    <div className="site-logo">
                    <Link to="/" className="d-block">
                        <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
                    </Link>
                    </div>
                    <div className="mr-auto">
                    <nav className="site-navigation position-relative text-right" role="navigation">
                        <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                        <li className="active">
                            <Link to="/" className="nav-link text-left">Home</Link>
                        </li>
                    
                        <li><Link to="/admissions" className="nav-link text-left">Admissions</Link></li>
                        <li><Link to="/courses" className="nav-link text-left">Courses</Link></li>
                        <li><Link to="/contact" className="nav-link text-left">Contact</Link></li>
                        </ul>
                    </nav>
                    </div>
                    <div className="ml-auto">
                    <div className="social-wrap">
                        <Link to="#"><span className="icon-facebook" /></Link>
                        <Link to="#"><span className="icon-twitter" /></Link>
                        <Link to="#"><span className="icon-linkedin" /></Link>
                        <Link to="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
                        <span className="icon-menu h3" />
                        </Link>
                    </div>
                    </div>
                </div>
            </div>
        </header>
        {/* Hero Section */}
        <div
        className="site-section ftco-subscribe-1 site-blocks-cover pb-4"
        style={{
            backgroundImage: "url('/assets/images/bg_1.jpg')",
            marginTop: '8rem',
            paddingTop: '2rem',
            paddingBottom: '2rem'
        }}
        >
        <div className="container">
            <div className="row align-items-end">
            <div className="col-lg-7">
                <h2 className="mb-0">Grades</h2>
                
            </div>
            </div>
        </div>
        </div>

        {/* Breadcrumbs */}
        <div className="custom-breadcrumns border-bottom">
        <div className="container">
            <Link to="/">Home</Link>
            <span className="mx-3 icon-keyboard_arrow_right"></span>
            <Link to="/grades">My Grades</Link>
        </div>
    </div>
    
    <div className="wrapper">
      <div className="container py-5">

        <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="thead-dark">
              <tr>
                <th onClick={() => handleSort('id')} style={{ cursor: 'pointer' }}>
                  ID {renderSortArrow('id')}
                </th>
                <th onClick={() => handleSort('name')} style={{ cursor: 'pointer' }}>
                  Name {renderSortArrow('name')}
                </th>
                <th onClick={() => handleSort('salary')} style={{ cursor: 'pointer' }}>
                  Salary {renderSortArrow('salary')}
                </th>
                <th onClick={() => handleSort('country')} style={{ cursor: 'pointer' }}>
                  Country {renderSortArrow('country')}
                </th>
                <th onClick={() => handleSort('city')} style={{ cursor: 'pointer' }}>
                  City {renderSortArrow('city')}
                </th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.map((row) =>
                editRowId === row.id ? (
                  <tr key={row.id}>
                    <td>{row.id}</td>
                    <td>
                      <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={editFormData.name}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        className="form-control"
                        name="salary"
                        value={editFormData.salary}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        className="form-control"
                        name="country"
                        value={editFormData.country}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        className="form-control"
                        name="city"
                        value={editFormData.city}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <button className="btn btn-sm btn-success mr-2" onClick={handleSaveEdit}>
                        Save
                      </button>
                      <button className="btn btn-sm btn-secondary" onClick={handleCancelEdit}>
                        Cancel
                      </button>
                    </td>
                  </tr>
                ) : (
                  <tr key={row.id}>
                    <td>{row.id}</td>
                    <td>{row.name}</td>
                    <td>{row.salary}</td>
                    <td>{row.country}</td>
                    <td>{row.city}</td>
                    <td>
                      <button className="btn btn-sm btn-warning mr-2" onClick={() => handleEditClick(row)}>Edit</button>
                      <button className="btn btn-sm btn-danger" onClick={() => handleDelete(row)}>Delete</button>
                    </td>
                  </tr>
                )
              )}
              {paginatedData.length === 0 && (
                <tr>
                  <td colSpan="6" className="text-center">No results found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="d-flex justify-content-between align-items-center mt-3">
          <div>
            Showing {Math.min((currentPage - 1) * pageSize + 1, filteredData.length)} to{' '}
            {Math.min(currentPage * pageSize, filteredData.length)} of {filteredData.length} entries
          </div>
          <div>
            <button
              className="btn btn-sm btn-outline-primary mr-2"
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              Previous
            </button>
            <span>Page {currentPage} of {totalPages}</span>
            <button
              className="btn btn-sm btn-outline-primary ml-2"
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>

    {/* Footer */}
    <div className="footer">
        <div className="container">
            <div className="row">
            <div className="col-lg-3">
                <p className="mb-4">
                <img src="/assets/images/logo.png" alt="Logo" className="img-fluid" />
                </p>
                <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.
                </p>
                <p><Link to="#">Learn More</Link></p>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Campus</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Academic</Link></li>
                <li><Link to="#">News</Link></li>
                <li><Link to="#">Our Interns</Link></li>
                <li><Link to="#">Our Leadership</Link></li>
                <li><Link to="#">Careers</Link></li>
                <li><Link to="#">Human Resources</Link></li>
                </ul>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Courses</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Math</Link></li>
                <li><Link to="#">Science &amp; Engineering</Link></li>
                <li><Link to="#">Arts &amp; Humanities</Link></li>
                <li><Link to="#">Economics &amp; Finance</Link></li>
                <li><Link to="#">Business Administration</Link></li>
                <li><Link to="#">Computer Science</Link></li>
                </ul>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Contact</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Help Center</Link></li>
                <li><Link to="#">Support Community</Link></li>
                <li><Link to="#">Press</Link></li>
                <li><Link to="#">Share Your Story</Link></li>
                <li><Link to="#">Our Supporters</Link></li>
                </ul>
            </div>
            </div>

            <div className="row">
            <div className="col-12">
                <div className="copyright">
                <p>
                    &copy; {new Date().getFullYear()} All rights reserved | This template is made with
                    <i className="icon-heart" aria-hidden="true"></i> by{' '}
                    <a href="https://colorlib.com" target="_blank" rel="noopener noreferrer">Colorlib</a>
                </p>
                </div>
            </div>
            </div>
        </div>
    </div>


    </>
  );
};

export default Grades;
