import React from 'react';
import { Link } from 'react-router-dom';

const MyCourseSingle = () => {
  return (
    <>
        {/* Top Bar */}
        <div className="py-2 bg-light">
            <div className="container">
            <div className="row align-items-center">
                <div className="col-lg-9 d-none d-lg-block">
                <Link to="#" className="small mr-3">
                    <span className="icon-question-circle-o mr-2"></span> Have a question?
                </Link>
                <Link to="#" className="small mr-3">
                    <span className="icon-phone2 mr-2"></span> 10 20 123 456
                </Link>
                <Link to="#" className="small mr-3">
                    <span className="icon-envelope-o mr-2"></span> info@mydomain.com
                </Link>
                </div>
                <div className="col-lg-3 text-right">
                <Link to="/login" className="small mr-3">
                    <span className="icon-unlock-alt"></span> Log In
                </Link>
                <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                    <span className="icon-users"></span> Register
                </Link>
                </div>
            </div>
            </div>
        </div>
    
        {/* Header/Navbar */}
        <header className="site-navbar py-4 site-navbar-target" role="banner">
            <div className="container">
                <div className="d-flex align-items-center">
                    <div className="site-logo">
                    <Link to="/" className="d-block">
                        <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
                    </Link>
                    </div>
                    <div className="mr-auto">
                    <nav className="site-navigation position-relative text-right" role="navigation">
                        <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                        <li className="active">
                            <Link to="/" className="nav-link text-left">Home</Link>
                        </li>
                    
                        <li><Link to="/admissions" className="nav-link text-left">Admissions</Link></li>
                        <li><Link to="/courses" className="nav-link text-left">Courses</Link></li>
                        <li><Link to="/contact" className="nav-link text-left">Contact</Link></li>
                        </ul>
                    </nav>
                    </div>
                    <div className="ml-auto">
                    <div className="social-wrap">
                        <Link to="#"><span className="icon-facebook" /></Link>
                        <Link to="#"><span className="icon-twitter" /></Link>
                        <Link to="#"><span className="icon-linkedin" /></Link>
                        <Link to="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
                        <span className="icon-menu h3" />
                        </Link>
                    </div>
                    </div>
                </div>
            </div>
        </header>
        {/* Hero Section */}
        <div
        className="site-section ftco-subscribe-1 site-blocks-cover pb-4"
        style={{
            backgroundImage: "url('/assets/images/bg_1.jpg')",
            marginTop: '8rem',
            paddingTop: '2rem',
            paddingBottom: '2rem'
        }}
        >
        <div className="container">
            <div className="row align-items-end">
            <div className="col-lg-7">
                <h2 className="mb-0">How To Create Mobile Apps Using Ionic</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            </div>
            </div>
        </div>
        </div>

        {/* Breadcrumbs */}
        <div className="custom-breadcrumns border-bottom">
        <div className="container">
            <Link to="/">Home</Link>
            <span className="mx-3 icon-keyboard_arrow_right"></span>
            <Link to="/courses">Courses</Link>
            <span className="mx-3 icon-keyboard_arrow_right"></span>
            <span className="current">Courses</span>
        </div>
        </div>
        {/* Course Details Section */}
    <div className="site-section">
        <div className="container">
            <div className="row">
            <div className="col-md-6 mb-4">
                <p>
                <img src="/assets/images/course_5.jpg" alt="Course" className="img-fluid" />
                </p>
            </div>
            <div className="col-lg-5 ml-auto align-self-center">
                <h2 className="section-title-underline mb-5">
                <span>Course Details</span>
                </h2>

                <p>
                <strong className="text-black d-block">Teacher:</strong> Craig Daniel
                </p>
                <p className="mb-5">
                <strong className="text-black d-block">Hours:</strong> 8:00 am — 9:30 am
                </p>
                <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. At itaque dolore libero corrupti! Itaque, delectus?
                </p>
                <p>
                Modi sit dolor repellat esse! Sed necessitatibus itaque libero odit placeat nesciunt, voluptatum totam facere.
                </p>

                <ul className="ul-check primary list-unstyled mb-5">
                <li>Lorem ipsum dolor sit amet consectetur</li>
                <li>consectetur adipisicing</li>
                <li>Sit dolor repellat esse</li>
                <li>Necessitatibus</li>
                <li>Sed necessitatibus itaque</li>
                </ul>

                
            </div>
            </div>
        </div>
    </div>
    {/* Why Choose Us Section */}
    <div className="section-bg style-1" style={{ backgroundImage: "url('/assets/images/hero_1.jpg')" }}>
        <div className="container">
            <div className="row">
            <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                <span className="icon flaticon-mortarboard"></span>
                <h3>Our Philosophy</h3>
                <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae, iure repellat quis delectus ea? Dolore, amet reprehenderit.
                </p>
            </div>
            <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                <span className="icon flaticon-school-material"></span>
                <h3>Academics Principle</h3>
                <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae, iure repellat quis delectus ea? Dolore, amet reprehenderit.
                </p>
            </div>
            <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                <span className="icon flaticon-library"></span>
                <h3>Key of Success</h3>
                <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae, iure repellat quis delectus ea? Dolore, amet reprehenderit.
                </p>
            </div>
            </div>
        </div>
    </div>
    {/* Footer */}
    <div className="footer">
        <div className="container">
            <div className="row">
            <div className="col-lg-3">
                <p className="mb-4">
                <img src="/assets/images/logo.png" alt="Logo" className="img-fluid" />
                </p>
                <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.
                </p>
                <p><Link to="#">Learn More</Link></p>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Campus</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Academic</Link></li>
                <li><Link to="#">News</Link></li>
                <li><Link to="#">Our Interns</Link></li>
                <li><Link to="#">Our Leadership</Link></li>
                <li><Link to="#">Careers</Link></li>
                <li><Link to="#">Human Resources</Link></li>
                </ul>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Courses</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Math</Link></li>
                <li><Link to="#">Science &amp; Engineering</Link></li>
                <li><Link to="#">Arts &amp; Humanities</Link></li>
                <li><Link to="#">Economics &amp; Finance</Link></li>
                <li><Link to="#">Business Administration</Link></li>
                <li><Link to="#">Computer Science</Link></li>
                </ul>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Contact</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Help Center</Link></li>
                <li><Link to="#">Support Community</Link></li>
                <li><Link to="#">Press</Link></li>
                <li><Link to="#">Share Your Story</Link></li>
                <li><Link to="#">Our Supporters</Link></li>
                </ul>
            </div>
            </div>

            <div className="row">
            <div className="col-12">
                <div className="copyright">
                <p>
                    &copy; {new Date().getFullYear()} All rights reserved | This template is made with
                    <i className="icon-heart" aria-hidden="true"></i> by{' '}
                    <a href="https://colorlib.com" target="_blank" rel="noopener noreferrer">Colorlib</a>
                </p>
                </div>
            </div>
            </div>
        </div>
    </div>


    </>
  );
};

export default MyCourseSingle;
