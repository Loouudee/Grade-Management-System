import React from 'react';

const UnauthorizedPage = () => {
  return (
    <div>
      <h1>Unauthorized</h1>
      <p>You do not have permission to view this page. Please check your credentials or role.</p>
    </div>
  );
};

export default UnauthorizedPage;
