import React from 'react';
import { Link } from 'react-router-dom';

const Admissions = () => {
  return (
    <>
      {/* Top Bar */}
      <div className="py-2 bg-light">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-9 d-none d-lg-block">
              <Link to="#" className="small mr-3">
                <span className="icon-question-circle-o mr-2" /> Have a question?
              </Link>
              <Link to="#" className="small mr-3">
                <span className="icon-phone2 mr-2" /> 10 20 123 456
              </Link>
              <Link to="#" className="small mr-3">
                <span className="icon-envelope-o mr-2" /> info@mydomain.com
              </Link>
            </div>
            <div className="col-lg-3 text-right">
              <Link to="/login" className="small mr-3">
                <span className="icon-unlock-alt" /> Log In
              </Link>
              <Link to="/register" className="small btn btn-primary px-4 py-2 rounded-0">
                <span className="icon-users" /> Register
              </Link>
            </div>
          </div>
        </div>
      </div>
        {/* Header / Navbar */}
    <header className="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
        <div className="container">
            <div className="d-flex align-items-center">
            <div className="site-logo">
                <Link to="/" className="d-block">
                <img src="/assets/images/logo.jpg" alt="Logo" className="img-fluid" />
                </Link>
            </div>
            <div className="mr-auto">
                <nav className="site-navigation position-relative text-right" role="navigation">
                <ul className="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                    <li>
                    <Link to="/" className="nav-link text-left">Home</Link>
                    </li>
                    
                    <li className="active">
                    <Link to="/admissions" className="nav-link text-left">Admissions</Link>
                    </li>
                    <li>
                    <Link to="/courses" className="nav-link text-left">Courses</Link>
                    </li>
                    <li>
                    <Link to="/contact" className="nav-link text-left">Contact</Link>
                    </li>
                </ul>
                </nav>
            </div>
            <div className="ml-auto">
                <div className="social-wrap">
                <Link to="#"><span className="icon-facebook"></span></Link>
                <Link to="#"><span className="icon-twitter"></span></Link>
                <Link to="#"><span className="icon-linkedin"></span></Link>
                <Link to="#" className="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black">
                    <span className="icon-menu h3" />
                </Link>
                </div>
            </div>
            </div>
        </div>
    </header>
    {/* Hero Section */}
    <div
    className="site-section ftco-subscribe-1 site-blocks-cover pb-4"
    style={{
        backgroundImage: "url('/assets/images/bg_1.jpg')",
        marginTop: '8rem',
        paddingTop: '2rem',
        paddingBottom: '2rem'
    }}
    >
        <div className="container">
            <div className="row align-items-end">
            <div className="col-lg-7">
                <h2 className="mb-0">Admissions</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            </div>
            </div>
        </div>
    </div>

    {/* Breadcrumbs */}
    <div className="custom-breadcrumns border-bottom">
        <div className="container">
            <Link to="/">Home</Link>
            <span className="mx-3 icon-keyboard_arrow_right"></span>
            <span className="current">Admission</span>
        </div>
    </div>

    {/* Admission Details Section */}
<div className="site-section">
  <div className="container">
    {/* College Requirements */}
    <div className="row mb-5">
      <div className="col-lg-6 mb-lg-0 mb-4">
        <img src="/assets/images/course_6.jpg" alt="College Requirements" className="img-fluid" />
      </div>
      <div className="col-lg-5 ml-auto align-self-center">
        <h2 className="section-title-underline mb-5">
          <span>College Requirements</span>
        </h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At itaque dolore libero corrupti! Itaque, delectus?</p>
        <p>Modi sit dolor repellat esse! Sed necessitatibus itaque libero odit placeat nesciunt, voluptatum totam facere.</p>

        <ol className="ul-check primary list-unstyled">
          <li>Accomplished Application Form</li>
          <li>High School Report Card</li>
          <li>High School Transcript</li>
          <li>Certificate of Good Moral Character</li>
          <li>2×2 picture</li>
          <li>1×1 picture</li>
        </ol>
      </div>
    </div>

    {/* Transferees */}
    <div className="row">
        <div className="col-lg-6 order-1 order-lg-2 mb-4 mb-lg-0">
            <img src="/assets/images/course_3.jpg" alt="Transferees" className="img-fluid" />
        </div>
        <div className="col-lg-5 mr-auto align-self-center order-2 order-lg-1">
            <h2 className="section-title-underline mb-5">
            <span>Transferees</span>
            </h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At itaque dolore libero corrupti! Itaque, delectus?</p>
            <p>Modi sit dolor repellat esse! Sed necessitatibus itaque libero odit placeat nesciunt, voluptatum totam facere.</p>
            <ol className="ul-check primary list-unstyled">
            <li>Accomplished Application Form</li>
            <li>High School Report Card</li>
            <li>High School Transcript</li>
            <li>Certificate of Good Moral Character</li>
            <li>2×2 picture</li>
            <li>1×1 picture</li>
            </ol>
        </div>
        </div>
    </div>
    </div>
    {/* Why Choose Us Section */}
    <div className="section-bg style-1" style={{ backgroundImage: "url('/assets/images/hero_1.jpg')" }}>
        <div className="container">
            <div className="row">
            <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                <span className="icon flaticon-mortarboard"></span>
                <h3>Our Philosophy</h3>
                <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae, iure repellat quis delectus ea?
                Dolore, amet reprehenderit.
                </p>
            </div>
            <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                <span className="icon flaticon-school-material"></span>
                <h3>Academics Principle</h3>
                <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae, iure repellat quis delectus ea?
                Dolore, amet reprehenderit.
                </p>
            </div>
            <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                <span className="icon flaticon-library"></span>
                <h3>Key of Success</h3>
                <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae, iure repellat quis delectus ea?
                Dolore, amet reprehenderit.
                </p>
            </div>
            </div>
        </div>
    </div>

    {/* Footer */}
    <div className="footer">
        <div className="container">
            <div className="row">
            <div className="col-lg-3">
                <p className="mb-4">
                <img src="/assets/images/logo.png" alt="Logo" className="img-fluid" />
                </p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>
                <p><Link to="#">Learn More</Link></p>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Campus</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Academic</Link></li>
                <li><Link to="#">News</Link></li>
                <li><Link to="#">Our Interns</Link></li>
                <li><Link to="#">Our Leadership</Link></li>
                <li><Link to="#">Careers</Link></li>
                <li><Link to="#">Human Resources</Link></li>
                </ul>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Our Courses</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Math</Link></li>
                <li><Link to="#">Science &amp; Engineering</Link></li>
                <li><Link to="#">Arts &amp; Humanities</Link></li>
                <li><Link to="#">Economics &amp; Finance</Link></li>
                <li><Link to="#">Business Administration</Link></li>
                <li><Link to="#">Computer Science</Link></li>
                </ul>
            </div>

            <div className="col-lg-3">
                <h3 className="footer-heading"><span>Contact</span></h3>
                <ul className="list-unstyled">
                <li><Link to="#">Help Center</Link></li>
                <li><Link to="#">Support Community</Link></li>
                <li><Link to="#">Press</Link></li>
                <li><Link to="#">Share Your Story</Link></li>
                <li><Link to="#">Our Supporters</Link></li>
                </ul>
            </div>
            </div>

            <div className="row">
            <div className="col-12">
                <div className="copyright">
                <p>
                    &copy; {new Date().getFullYear()} All rights reserved | This template is made with{' '}
                    <i className="icon-heart" aria-hidden="true"></i> by{' '}
                    <a href="https://colorlib.com" target="_blank" rel="noopener noreferrer">Colorlib</a>
                </p>
                </div>
            </div>
            </div>
        </div>
    </div>


    </>
  );
};

export default Admissions;
