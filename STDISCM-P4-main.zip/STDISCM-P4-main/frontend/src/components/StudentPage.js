export default function StudentPage() {
    return <h2>Student Page: Only students can access this</h2>;
}