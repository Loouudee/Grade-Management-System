export default function PublicPage() {
    return <h2>Public Page: Anyone can see this</h2>;
  }