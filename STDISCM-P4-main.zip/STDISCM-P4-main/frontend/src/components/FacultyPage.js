export default function FacultyPage() {
    return <h2>Faculty Page: Only faculty can access this</h2>;
}