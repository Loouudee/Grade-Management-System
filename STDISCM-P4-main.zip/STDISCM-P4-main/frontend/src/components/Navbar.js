// components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav>
      <Link to="/">Public</Link> | 
      <Link to="/student">Student</Link> | 
      <Link to="/faculty">Faculty</Link> | 
      <Link to="/login">Login</Link> | 
      <Link to="/signup">Signup</Link>
    </nav>
  );
};

export default Navbar;
