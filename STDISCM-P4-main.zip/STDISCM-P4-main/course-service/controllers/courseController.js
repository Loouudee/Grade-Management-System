const Course = require('../models/courseModel');

exports.createCourse = async (req, res) => {
  try {
    const newCourse = new Course({ ...req.body, faculty: req.user.id });
    const savedCourse = await newCourse.save();
    res.status(201).json(savedCourse);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAllCourses = async (req, res) => {
  try {
    //const courses = await Course.find().populate('faculty', 'name');
    const courses = await Course.find();

    res.json(courses);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getCourseById = async (req, res) => {
  try {
    console.log(req.params.id);  // Log the ID
    const course = await Course.findById(req.params.id);

    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    res.json(course);
  } catch (err) {
    console.error(err);  // Log any errors
    res.status(500).json({ error: err.message });
  }
};

